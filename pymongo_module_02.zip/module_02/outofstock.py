#Write a program to accept ID, fetch the document from collection, 
#copy it in another collection "outofstock" and delete the document 
#from the "mobiles" collection


from pymongo import MongoClient

id=int(input("enter the mobile id: "))
qr={}
qr["_id"]=id

client=MongoClient("mongodb://localhost:27017")
db=client["shopping"]
coll=db["mobiles"]
coll2=db["outofstock"]

for doc in coll.find(qr):

    print(doc)

print("\n the document has been successfully copied to outofstock db\n")
coll2.insert_one(doc)
print(doc)
coll.delete_one(doc)
print("\n the document has been deleted from mobiles db")


