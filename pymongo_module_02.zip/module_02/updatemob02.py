#Write a program to accept ID, ram and rom. Update the document 
#with new ram and rom of the model.

from pymongo import MongoClient

id=int(input("Enter the id of the mobile: "))
ram=int(input("enter RAM : "))
rom=int(input("enter ROM : "))

dic={}
dic["_id"]=id
dic["ram"]=ram
dic["rom"]=rom

nram=int(input("Enter new RAM : "))
nrom=int(input("Enter new ROM : "))

qr={}
qr["ram"]=nram
qr["rom"]=nrom

upd={"$set":qr}

client=MongoClient("mongodb://localhost:27017")
db=client["shopping"]
coll=db["mobiles"]

coll.update_many(dic,upd)
print("RAM and ROM are updated successfully....")

