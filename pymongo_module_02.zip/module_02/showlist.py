#Write a program to show list of all documents from the collection

from pymongo import MongoClient
client=MongoClient("mongodb://localhost:27017")
db=client["shopping"]
coll=db["mobiles"]
for doc in coll.find():
    

     print("%s | %s | %s | %s | %s | %s | %s | %s | %s | %.1f"%(doc["_id"],doc["company"],doc["model"],doc["processor"],doc["screensize"],doc["ram"],doc["rom"],doc["connectivity"],doc["price"],doc["rating"]))
    
        