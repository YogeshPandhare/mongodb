#Write a python program to take input from the user and add employee 
#data as a document in the collection

from pymongo import MongoClient 
client=MongoClient("mongodb://localhost:27017")
db=client["shopping"]
coll=db["mobiles"]

id=int(input("enter the id: "))
co=input("enter the phone company: ")
mo=input("enter the model name: ")
proc=input("enter the processor of the phone: ")
sc=input("enter the screensize: ")
ram=int(input("enter the RAM: "))
rom=int(input("enter the ROM: "))
con=input("connectivity: ")
pr=int(input("enter the price: "))
rt=float(input("enter the rating: "))

dic={}
dic["_id"]=id 
dic["company"]=co 
dic["model"]=mo
dic["processor"]=proc
dic["screensize"]=sc
dic["ram"]=ram
dic["rom"]=rom
dic["connectivity"]=con
dic["price"]=pr
dic["rating"]=rt

coll.insert_one(dic)
print("new phone added to collection successfully") 


