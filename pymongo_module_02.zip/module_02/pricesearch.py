#Write a program to accept price and display all documents having 
#price less than the input value

from pymongo import MongoClient
client=MongoClient("mongodb://localhost:27017")
db=client["shopping"]
coll=db["mobiles"]

pri=int(input("Enter your price range: "))
qr={}
qr["price"]=pri
qr1={"price":{"$lt":pri}}

print("these are the phones according to your price range :\n")
for doc in coll.find(qr1):
    print(doc)

   
