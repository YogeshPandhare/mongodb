#Write a program to take company as an input and display documents 
#of all mobiles of the company

from pymongo import MongoClient 
client=MongoClient("mongodb://localhost:27017")
db=client["shopping"]
coll=db["mobiles"]

co=input("enter mobile company: ")
qr={}
qr["company"]=co

for doc in coll.find(qr):
    print(doc)
   