#Write a program to accept ID and new price of the mobile. Update 
#the document with new price. Display the document after updating.

from pymongo import MongoClient

id=int(input('Enter mobile ID: '))
qr={}
qr["_id"]=id


nprice=int(input('Enter the new price: '))
ch={}
ch["price"]=nprice

upd={"$set":ch}

client=MongoClient("mongodb://localhost:27017")
db=client["shopping"]
coll=db["mobiles"]

coll.update_one(qr,upd)
for doc in coll.find(qr):
    print(doc)

print('price updated successfully....')


